
Date of compilation: 21-February-2014
Xiaofan Chen <xiaofanc AT gmail dot com)

Please use libftdi mailing list for support. I do not
reply to technical questions through private email.

To use libftdi1-1.1 under Windows, you need to use libusbx 
and supported drivers.

The copyright information about libftdi1 and libusb are 
inside the copyright directory.

The html_doc directory is the doxygen generated HTML document 
for libftdi1-1.1. libusb is at the following URL.
  http://libusb.info/

The bin directory contains the dlls and example programs for 
libftdi1-1.1 and libusb 1.0.18 Windows. 

The source code libftdi1-1.1 and libusb-1.0.18 release 
for the build are also included in the src directory 
for convenience.

Tools used to build this package:
  CMake 2.8.10.2: http://www.cmake.org/
  MinGW-w64 GCC 4.8.2 x86 and x64 (mingw-builds personal build) : http://sourceforge.net/projects/mingw-w64/
  doxygen 1.8.3: http://www.doxygen.org/
  libconfuse 2.7: http://www.nongnu.org/confuse/
  pkg-config lite 0.28_1 :http://sourceforge.net/projects/pkgconfiglite/
  Boost 1.55 (source only): http://www.boost.org
  Python 3.3.0 x86 and x64: http://www.python.org
  swig 2.09: http://www.swig.org/


