
You need to install libusb Windows backend supported drivers 
in order to use libftdi1 under Windows. You can usesing Zadig 
from the libwdi project to do that. 
 Zadig: http://zadig.akeo.ie/

In general, you should use WinUSB driver since it is the best
supported by libusb Windows backend. You should avoid
using libusb0.sys as it is not well supported by libusb
Windows backend yet.


